# NFT Marketplace

A decentralized marketplace for buying, selling, and trading NFTs, built with Solidity and React.